import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Solutions from './components/Solutions';
import CaseStudies from './components/CaseStudies';
import About from './components/About';
import CTABanner from './components/CTABanner';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 font-sans text-white antialiased">
      <Header />
      <main>
        <Hero />
        <Services />
        <Solutions />
        <CaseStudies />
        <About />
        <CTABanner />
      </main>
      <Footer />
    </div>
  );
}
