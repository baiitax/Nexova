import { motion } from 'framer-motion';
import { Wrench, HeartPulse, Building2 } from 'lucide-react';

const services = [
  {
    icon: Wrench,
    title: 'Home Services & Trades',
    description:
      'Roofing, HVAC, plumbing, and custom landscaping. We capture your emergency leads and automate your vendor dispatch.',
    color: 'text-amber-400',
    bg: 'from-amber-500/20 to-orange-500/20',
  },
  {
    icon: HeartPulse,
    title: 'Medical & Aesthetic Clinics',
    description:
      'MedSpas and specialized clinics. We implement AI receptionists and automated booking systems so you never miss a patient.',
    color: 'text-pink-400',
    bg: 'from-pink-500/20 to-rose-500/20',
  },
  {
    icon: Building2,
    title: 'B2B Leaders & Manufacturing',
    description:
      'Commercial contractors and fabricators. We build automated CRM pipelines and RFQ sorting to speed up your sales cycle.',
    color: 'text-cyan-400',
    bg: 'from-cyan-500/20 to-blue-500/20',
  },
];

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, delay: i * 0.15 },
  }),
};

export default function Services() {
  return (
    <section id="services" className="relative px-6 py-24">
      <div className="mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <span className="mb-4 inline-block rounded-full border border-cyan-500/20 bg-cyan-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-cyan-400">
            Who We Serve
          </span>
          <h2 className="mt-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">
            Built for <span className="gradient-text">High-Ticket Industries</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-400">
            We partner specifically with high-ticket, local, and B2B service providers who need
            speed, reliability, and measurable ROI.
          </p>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-3">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              custom={i}
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              className="glass-card group rounded-2xl p-8 transition-all hover:border-cyan-500/20"
            >
              <div
                className={`mb-6 flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br ${service.bg}`}
              >
                <service.icon className={`h-7 w-7 ${service.color}`} />
              </div>
              <h3 className="mb-3 text-xl font-bold text-white">{service.title}</h3>
              <p className="text-sm leading-relaxed text-slate-400">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
