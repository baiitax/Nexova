import { motion } from 'framer-motion';
import { TrendingUp, Globe, Timer } from 'lucide-react';

const caseStudies = [
  {
    icon: TrendingUp,
    company: 'Radiant MedSpa',
    industry: 'Medical & Aesthetic',
    highlight: 'AI Scheduler increased bookings by 34% in 30 days.',
    metric: '+34%',
    metricLabel: 'Bookings',
    color: 'text-pink-400',
    borderColor: 'hover:border-pink-500/30',
    bg: 'from-pink-500/20 to-rose-500/20',
  },
  {
    icon: Globe,
    company: 'Oak Ridge Roofing',
    industry: 'Home Services',
    highlight:
      'Instant web deployment generated 12 new high-ticket leads in month one.',
    metric: '12',
    metricLabel: 'New Leads',
    color: 'text-amber-400',
    borderColor: 'hover:border-amber-500/30',
    bg: 'from-amber-500/20 to-orange-500/20',
  },
  {
    icon: Timer,
    company: 'Sentinel Property Mgmt',
    industry: 'B2B Property Management',
    highlight: 'Automated triage reduced vendor dispatch time by 50%.',
    metric: '50%',
    metricLabel: 'Time Saved',
    color: 'text-cyan-400',
    borderColor: 'hover:border-cyan-500/30',
    bg: 'from-cyan-500/20 to-teal-500/20',
  },
];

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, delay: i * 0.15 },
  }),
};

export default function CaseStudies() {
  return (
    <section id="case-studies" className="relative px-6 py-24">
      <div className="mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <span className="mb-4 inline-block rounded-full border border-cyan-500/20 bg-cyan-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-cyan-400">
            Proven Results
          </span>
          <h2 className="mt-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">
            Real Results from <span className="gradient-text">Industry Leaders</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-400">
            Don't take our word for it. Here's what our partners have achieved.
          </p>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-3">
          {caseStudies.map((cs, i) => (
            <motion.div
              key={cs.company}
              custom={i}
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              className={`glass-card group rounded-2xl p-8 transition-all ${cs.borderColor}`}
            >
              <div className="mb-6 flex items-center justify-between">
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${cs.bg}`}
                >
                  <cs.icon className={`h-6 w-6 ${cs.color}`} />
                </div>
                <div className="text-right">
                  <div className={`text-2xl font-extrabold ${cs.color}`}>{cs.metric}</div>
                  <div className="text-xs text-slate-500">{cs.metricLabel}</div>
                </div>
              </div>
              <div className="mb-1 text-xs font-semibold uppercase tracking-wider text-slate-500">
                {cs.industry}
              </div>
              <h3 className="mb-3 text-xl font-bold text-white">{cs.company}</h3>
              <p className="text-sm leading-relaxed text-slate-400">{cs.highlight}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
