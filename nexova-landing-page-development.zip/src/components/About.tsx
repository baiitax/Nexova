import { motion } from 'framer-motion';
import { Zap, MessageCircle, BarChart3, Quote } from 'lucide-react';

const values = [
  {
    icon: Zap,
    title: 'Speed to Market',
    description:
      'In business, speed wins. We deploy your web architecture and automation workflows in days, not months.',
    color: 'text-amber-400',
    bg: 'from-amber-500/20 to-orange-500/20',
  },
  {
    icon: MessageCircle,
    title: 'Radical Candor',
    description:
      "We don't sell you things you don't need. If your website is fine but your booking system is broken, we will tell you exactly where the real bottleneck is.",
    color: 'text-cyan-400',
    bg: 'from-cyan-500/20 to-teal-500/20',
  },
  {
    icon: BarChart3,
    title: 'Measurable ROI',
    description:
      'Every line of code we write and every automation we build is designed with one metric in mind: increasing your revenue and lowering your overhead.',
    color: 'text-emerald-400',
    bg: 'from-emerald-500/20 to-green-500/20',
  },
];

const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, delay: i * 0.15 },
  }),
};

export default function About() {
  return (
    <section id="about" className="relative px-6 py-24">
      <div className="mx-auto max-w-7xl">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <span className="mb-4 inline-block rounded-full border border-cyan-500/20 bg-cyan-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-cyan-400">
            About Nexova
          </span>
          <h2 className="mt-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">
            We Turn Operational Bottlenecks into{' '}
            <span className="gradient-text">Automated Revenue Engines</span>
          </h2>
          <p className="mx-auto mt-4 max-w-3xl text-lg text-slate-400">
            At Nexova, we know that you are an expert in your trade. But being exceptional at your
            craft doesn't mean you should have to be an expert in digital infrastructure.
          </p>
        </motion.div>

        {/* The Nexova Difference */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6 }}
          className="glass-card mx-auto mb-20 max-w-4xl rounded-2xl p-8 sm:p-12"
        >
          <h3 className="mb-4 text-2xl font-bold text-white">The Nexova Difference</h3>
          <p className="mb-4 text-slate-400 leading-relaxed">
            Most digital agencies will sell you a pretty website and disappear. Most software
            companies will sell you a complex tool and expect you to learn how to use it.
          </p>
          <p className="text-slate-400 leading-relaxed">
            We do things differently. We are an end-to-end digital partner that blends{' '}
            <span className="font-semibold text-cyan-400">Rapid Web Development</span> with{' '}
            <span className="font-semibold text-cyan-400">Intelligent Business Automation</span>.
            We don't just build sites that look good; we engineer systems that do the heavy lifting
            for you—capturing leads, answering missed calls with AI, and automating your
            administrative workflows so your team can focus on closing deals and delivering great
            service.
          </p>
        </motion.div>

        {/* Meet the Founder */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6 }}
          className="mb-20 grid items-center gap-10 lg:grid-cols-2"
        >
          <div className="glass-card flex flex-col items-center justify-center rounded-2xl p-10 text-center">
            <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500/30 to-teal-500/30">
              <span className="text-4xl font-bold text-cyan-400">B</span>
            </div>
            <h4 className="text-xl font-bold text-white">Baita</h4>
            <p className="mt-1 text-sm text-cyan-400">Founder & Lead Developer</p>
            <div className="mt-6 flex items-start gap-2">
              <Quote className="mt-1 h-5 w-5 flex-shrink-0 text-cyan-500/50" />
              <p className="text-sm italic text-slate-400">
                "Technology should work for your business, not the other way around."
              </p>
            </div>
          </div>

          <div>
            <p className="mb-4 text-slate-400 leading-relaxed">
              As a Senior Developer and business entrepreneur, I saw a massive gap between the
              incredible technology available today and the daily reality of local business owners. I
              watched highly-rated companies lose out to inferior competitors simply because their
              digital presence was outdated or their front desk was overwhelmed.
            </p>
            <p className="text-slate-400 leading-relaxed">
              I founded Nexova to bridge that gap. My goal is to bring enterprise-grade web
              architecture and AI automation down to the local and B2B level, giving you the exact
              systems you need to scale without the friction. When you work with Nexova, you aren't
              just getting a developer—you are getting a{' '}
              <span className="font-semibold text-white">
                strategic partner invested in your bottom line
              </span>
              .
            </p>
          </div>
        </motion.div>

        {/* Core Values */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h3 className="text-2xl font-bold text-white sm:text-3xl">Our Core Values</h3>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-3">
          {values.map((value, i) => (
            <motion.div
              key={value.title}
              custom={i}
              variants={fadeInUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              className="glass-card rounded-2xl p-8 transition-all hover:border-cyan-500/20"
            >
              <div
                className={`mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${value.bg}`}
              >
                <value.icon className={`h-6 w-6 ${value.color}`} />
              </div>
              <h4 className="mb-2 text-lg font-bold text-white">{value.title}</h4>
              <p className="text-sm leading-relaxed text-slate-400">{value.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
