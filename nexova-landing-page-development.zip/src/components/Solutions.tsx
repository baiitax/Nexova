import { motion } from 'framer-motion';
import { Rocket, Bot, CheckCircle } from 'lucide-react';

const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.15 },
  }),
};

const webFeatures = [
  'AI-Powered Prototyping',
  'Instant Global Deployment',
  'SEO-Optimized Architecture',
  'Custom Domains & Analytics',
  'Secure Stripe Payment Integration',
];

const autoFeatures = [
  'Missed-Call Text-Back & Qualifying',
  'AI Appointment Scheduling',
  'Maintenance Triage & Vendor Dispatch',
  'Automated B2B Quoting Pipelines',
  'Hands-Free CRM Syncing',
];

export default function Solutions() {
  return (
    <section id="solutions" className="relative px-6 py-24">
      <div className="mx-auto max-w-7xl">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <span className="mb-4 inline-block rounded-full border border-cyan-500/20 bg-cyan-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-cyan-400">
            Our Solutions
          </span>
          <h2 className="mt-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">
            Comprehensive Solutions for{' '}
            <span className="gradient-text">High-Ticket Businesses</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-400">
            Two pillars. One integrated platform. Everything your business needs to dominate online.
          </p>
        </motion.div>

        {/* Two columns */}
        <div className="grid gap-8 lg:grid-cols-2">
          {/* Web Solutions Card */}
          <motion.div
            custom={0}
            variants={fadeInUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-80px' }}
            className="glass-card group rounded-2xl p-8 transition-all hover:border-cyan-500/20 lg:p-10"
          >
            <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500/20 to-teal-500/20">
              <Rocket className="h-7 w-7 text-cyan-400" />
            </div>
            <h3 className="mb-2 text-xs font-bold uppercase tracking-widest text-cyan-400">
              Rapid Web Solutions
            </h3>
            <p className="mb-6 text-lg font-semibold text-white">
              Lightning-fast websites that convert visitors into customers.
            </p>
            <ul className="space-y-4">
              {webFeatures.map((feature) => (
                <li key={feature} className="flex items-start gap-3">
                  <CheckCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-emerald-400" />
                  <span className="text-sm text-slate-300">{feature}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Automation Card */}
          <motion.div
            custom={1}
            variants={fadeInUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-80px' }}
            className="glass-card group rounded-2xl p-8 transition-all hover:border-cyan-500/20 lg:p-10"
          >
            <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20">
              <Bot className="h-7 w-7 text-purple-400" />
            </div>
            <h3 className="mb-2 text-xs font-bold uppercase tracking-widest text-purple-400">
              Intelligent Business Automation
            </h3>
            <p className="mb-6 text-lg font-semibold text-white">
              AI-powered workflows that run your business 24/7.
            </p>
            <ul className="space-y-4">
              {autoFeatures.map((feature) => (
                <li key={feature} className="flex items-start gap-3">
                  <CheckCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-emerald-400" />
                  <span className="text-sm text-slate-300">{feature}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
