import { motion } from 'framer-motion';

export default function CTABanner() {
  return (
    <section id="contact" className="relative px-6 py-24">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-100px' }}
        transition={{ duration: 0.6 }}
        className="mx-auto max-w-5xl overflow-hidden rounded-3xl"
      >
        <div
          className="relative px-8 py-16 text-center sm:px-16 sm:py-20"
          style={{
            background: 'linear-gradient(135deg, #0891b2 0%, #06b6d4 30%, #2563eb 100%)',
          }}
        >
          {/* Decorative circles */}
          <div className="pointer-events-none absolute top-0 right-0 h-64 w-64 rounded-full bg-white/5 -translate-y-1/2 translate-x-1/2" />
          <div className="pointer-events-none absolute bottom-0 left-0 h-48 w-48 rounded-full bg-white/5 translate-y-1/2 -translate-x-1/2" />

          <h2 className="relative mb-4 text-3xl font-extrabold text-white sm:text-4xl md:text-5xl">
            Ready to modernize your operations?
          </h2>
          <p className="relative mx-auto mb-8 max-w-xl text-lg text-white/80">
            Stop losing leads and start scaling. Let's build your custom growth blueprint together.
          </p>
          <a
            href="#"
            className="relative inline-flex items-center gap-2 rounded-xl bg-slate-950 px-8 py-4 text-base font-bold text-white transition-all hover:scale-105 hover:bg-slate-900"
            style={{ boxShadow: '0 0 30px rgba(0,0,0,0.3)' }}
          >
            Book Your Strategy Call
          </a>
        </div>
      </motion.div>
    </section>
  );
}
